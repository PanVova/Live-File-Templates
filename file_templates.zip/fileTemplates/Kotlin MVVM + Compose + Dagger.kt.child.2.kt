package ${PACKAGE_NAME}


import androidx.lifecycle.ViewModel
import javax.inject.Inject

#parse("File Header.java")
class ${NAME}ViewModel @Inject constructor(): ViewModel(){
  init {

  }
}