package ${PACKAGE_NAME}


import dagger.Module

@Module
class ${NAME}Module {
}