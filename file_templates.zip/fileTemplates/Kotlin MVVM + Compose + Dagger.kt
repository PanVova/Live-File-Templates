package ${PACKAGE_NAME}

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed
import androidx.compose.ui.tooling.preview.Preview
import androidx.fragment.app.Fragment
import javax.inject.Inject

#parse("File Header.java")
class ${NAME}Fragment: Fragment(){

  @Inject
  protected lateinit var viewModel: ${NAME}ViewModel

  override fun onAttach(context: Context) {
    ${NAME}Component.create().inject(this)
    super.onAttach(context)
  }

  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View {
    return ComposeView(requireContext()).apply {
      setViewCompositionStrategy(DisposeOnViewTreeLifecycleDestroyed)
      setContent {
        ${NAME}Fragment()
      }
    }
  }

  @Preview(showBackground = true)
  @Composable
  fun ${NAME}Fragment() {
  }
}