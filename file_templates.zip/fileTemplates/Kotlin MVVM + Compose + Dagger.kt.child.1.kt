package ${PACKAGE_NAME}

import dagger.Component

@Component(
  modules = [
    ${NAME}Module::class
  ]
)
interface ${NAME}Component {

  @Component.Builder
  interface Builder {
    fun build(): ${NAME}Component
  }

  fun inject(${NAME}Fragment: ${NAME}Fragment)

  companion object {
    fun create(): ${NAME}Component =
      Dagger${NAME}Component.builder()
        .build()
  }
}
